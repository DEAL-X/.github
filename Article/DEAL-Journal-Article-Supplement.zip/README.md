# DEAL.JS synthetic case-validation supplement

## Contents

- `deal-case-helpers.js`: standalone helper functions for normalization, validation, record transformation, JSON Lines serialization, selector extraction, and an in-memory resource adapter.
- `deal-case-validation.test.js`: deterministic Node.js tests for the synthetic five-record catalog used in the manuscript.
- `test-results.txt`: captured output from the validation run, including the accepted and rejected records.

## Reproduce the checks

Install Node.js (the recorded run used Node.js v22.16.0), change to this directory, and execute:

```bash
node deal-case-validation.test.js
```

The recorded suite reports **19/19 case-validation checks passed**, with **2 of 5 records accepted and 3 of 5 rejected**. The fixture includes a duplicate identifier, a missing main price, and a discount above the permitted interval. It also checks Unicode NFKC normalization, whitespace cleanup, derived net price, preservation of valid zero values, provenance, JSONL serialization, in-memory storage, and a document-shaped selector test double.

## Scope and limitations

All catalog rows and timestamps are synthetic. `https://example.org/catalog` is a placeholder source identifier, not a real acquisition endpoint. The suite performs no live network scraping, contains no human-participant data, and does not benchmark compiler speed or assess general DEAL.JS compiler conformance. The selector test uses a minimal document-shaped test double rather than a browser integration test.

This supplement is a **reconstruction from the manuscript's stated fixture and contracts** because the supplied article did not include the original executable case helper or original test script. It therefore does not independently authenticate a previously reported run. It makes the reconstructed data-contract checks executable and inspectable; it should not be described as a reproduction of whole-system results.

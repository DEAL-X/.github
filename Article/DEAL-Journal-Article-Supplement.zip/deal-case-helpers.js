'use strict';

const SCHEMA_VERSION = '1.0.0';

function normalizeTitle(value) {
    return String(value == null ? '' : value)
        .normalize('NFKC')
        .replace(/\s+/gu, ' ')
        .trim();
}

function normalizeIdentifier(value) {
    return String(value == null ? '' : value).trim();
}

function toFiniteNumber(value) {
    if (value == null || (typeof value === 'string' && value.trim() === '')) return null;
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
}

function extractRows(documentLike, sourceUrl = '') {
    if (!documentLike || typeof documentLike.querySelectorAll !== 'function') {
        throw new TypeError('A document-like object with querySelectorAll is required.');
    }
    return Array.from(documentLike.querySelectorAll('table.catalog tbody tr'), (row, index) => {
        const read = selector => {
            const element = row.querySelector(selector);
            return element ? String(element.textContent ?? '').trim() : '';
        };
        return {
            id: row.getAttribute('data-id') || '',
            title: read('.title'),
            main_price: read('.price'),
            discount: read('.discount'),
            quantity: read('.quantity'),
            source_url: sourceUrl,
            source_row: index + 1
        };
    });
}

function normalizeRecords(rows = [], sourceUrl = '', retrievedAt = '') {
    if (!Array.isArray(rows)) throw new TypeError('rows must be an array.');
    const accepted = [];
    const rejected = [];
    const seen = new Set();

    rows.forEach((raw, index) => {
        const sourceRow = Number.isSafeInteger(raw?.source_row) && raw.source_row > 0
            ? raw.source_row : index + 1;
        const id = normalizeIdentifier(raw?.id);
        const title = normalizeTitle(raw?.title);
        const price = toFiniteNumber(raw?.main_price);
        const discount = toFiniteNumber(raw?.discount);
        const quantityValue = toFiniteNumber(raw?.quantity);
        let reason = null;

        if (!id) reason = 'missing_id';
        else if (!title) reason = 'missing_title';
        else if (price === null || price < 0) reason = 'invalid_main_price';
        else if (discount === null || discount < 0 || discount > 1) reason = 'invalid_discount';
        else if (quantityValue === null || !Number.isSafeInteger(quantityValue) || quantityValue < 0) reason = 'invalid_quantity';
        else if (seen.has(id)) reason = 'duplicate_id';

        if (reason) {
            rejected.push({ source_row: sourceRow, id, reason });
            return;
        }

        // Register an ID only after every data validation rule has passed.
        seen.add(id);
        accepted.push({
            id,
            title,
            main_price: price,
            discount,
            quantity: quantityValue,
            net_price: Math.round((price * (1 - discount) + Number.EPSILON) * 100) / 100,
            source_url: String(raw?.source_url || sourceUrl),
            retrieved_at: retrievedAt,
            schema_version: SCHEMA_VERSION
        });
    });

    return { accepted, rejected };
}

function toJSONL(records) {
    return records.map(record => JSON.stringify(record)).join('\n') + (records.length ? '\n' : '');
}

function createMemoryResourceProvider() {
    const store = new Map();
    return {
        save(path, contents) { store.set(String(path), String(contents)); return true; },
        read(path) { return store.has(String(path)) ? store.get(String(path)) : null; },
        exists(path) { return store.has(String(path)); },
        entries() { return Array.from(store.entries()); }
    };
}

module.exports = {
    SCHEMA_VERSION,
    normalizeTitle,
    normalizeIdentifier,
    toFiniteNumber,
    extractRows,
    normalizeRecords,
    toJSONL,
    createMemoryResourceProvider
};

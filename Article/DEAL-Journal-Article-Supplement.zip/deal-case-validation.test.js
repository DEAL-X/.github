'use strict';
const assert = require('node:assert/strict');
const {
    SCHEMA_VERSION, extractRows, normalizeRecords, toJSONL, createMemoryResourceProvider
} = require('./deal-case-helpers');

const sourceUrl = 'https://example.org/catalog';
const fixedTimestamp = '2026-10-20T12:00:00.000Z'; // Synthetic fixture metadata, not a measured retrieval time.
const fixture = [
    { id: ' P1 ', title: '  Alpha   study ', main_price: '100', discount: '0.10', quantity: '2', source_row: 1 },
    { id: 'P1', title: 'Duplicate alpha', main_price: 100, discount: 0.10, quantity: 2, source_row: 2 },
    { id: 'P2', title: 'Ｂeta   study', main_price: 0, discount: 0, quantity: 0, source_row: 3 },
    { id: 'P3', title: 'Missing price', discount: 0, quantity: 1, source_row: 4 },
    { id: 'P4', title: 'Invalid discount', main_price: 10, discount: 1.25, quantity: 1, source_row: 5 }
];
const report = normalizeRecords(fixture, sourceUrl, fixedTimestamp);
let passed = 0;
function check(name, callback) {
    try { callback(); passed++; console.log('PASS', String(passed).padStart(2, '0'), name); }
    catch (error) { console.error('FAIL', name); throw error; }
}

check('two of five fixture records are accepted', () => assert.equal(report.accepted.length, 2));
check('three of five fixture records are rejected', () => assert.equal(report.rejected.length, 3));
check('identifier and title normalization are applied', () => {
    assert.equal(report.accepted[0].id, 'P1');
    assert.equal(report.accepted[0].title, 'Alpha study');
});
check('derived net price is correct to two decimals', () => assert.equal(report.accepted[0].net_price, 90));
check('Unicode NFKC normalization handles the full-width initial', () => assert.equal(report.accepted[1].title, 'Beta study'));
check('zero price, discount, and quantity remain valid zero values', () => {
    assert.deepEqual([report.accepted[1].main_price, report.accepted[1].discount, report.accepted[1].quantity], [0, 0, 0]);
    assert.equal(report.accepted[1].net_price, 0);
});
check('duplicate identifier is rejected after the first valid record', () => assert.equal(report.rejected[0].reason, 'duplicate_id'));
check('missing price is rejected rather than coerced to zero', () => assert.equal(report.rejected[1].reason, 'invalid_main_price'));
check('discount above one is rejected', () => assert.equal(report.rejected[2].reason, 'invalid_discount'));
check('rejections preserve the one-based source-row positions', () => assert.deepEqual(report.rejected.map(x => x.source_row), [2, 4, 5]));
check('accepted rows carry source, synthetic timestamp, and schema provenance', () => {
    assert.equal(report.accepted[0].source_url, sourceUrl);
    assert.equal(report.accepted[0].retrieved_at, fixedTimestamp);
    assert.equal(report.accepted[0].schema_version, SCHEMA_VERSION);
});
check('JSON Lines serialization round-trips the accepted records', () => assert.deepEqual(toJSONL(report.accepted).trimEnd().split('\n').map(JSON.parse), report.accepted));
check('memory resource provider writes and reads output consistently', () => {
    const provider = createMemoryResourceProvider();
    provider.save('accepted.jsonl', toJSONL(report.accepted));
    assert.equal(provider.exists('accepted.jsonl'), true);
    assert.equal(provider.read('accepted.jsonl'), toJSONL(report.accepted));
});
check('accepted records expose numeric fields with the declared types', () => {
    assert.equal(typeof report.accepted[0].main_price, 'number');
    assert.equal(typeof report.accepted[0].discount, 'number');
    assert.equal(Number.isSafeInteger(report.accepted[0].quantity), true);
});
check('the fixture produces the three specified rejection categories', () => assert.deepEqual(report.rejected.map(x => x.reason), ['duplicate_id', 'invalid_main_price', 'invalid_discount']));
check('an invalid record does not reserve its identifier', () => {
    const result = normalizeRecords([
        { id: 'X', title: 'bad price', main_price: null, discount: 0, quantity: 1 },
        { id: 'X', title: 'valid later', main_price: 1, discount: 0, quantity: 1 }
    ], sourceUrl, fixedTimestamp);
    assert.equal(result.accepted.length, 1);
    assert.equal(result.accepted[0].title, 'valid later');
});

const makeElement = textContent => ({ textContent });
const makeRow = (id, cells) => ({
    getAttribute: name => name === 'data-id' ? id : null,
    querySelector: selector => cells[selector] == null ? null : makeElement(cells[selector])
});
const fakeDocument = {
    querySelectorAll(selector) {
        assert.equal(selector, 'table.catalog tbody tr');
        return [makeRow('DOM-1', { '.title':'Title A', '.price':'5', '.discount':'0', '.quantity':'1' })];
    }
};
const extracted = extractRows(fakeDocument, sourceUrl);
check('document-shaped selector finds the expected row', () => assert.equal(extracted.length, 1));
check('extracted selector row preserves the ID and title fields', () => {
    assert.equal(extracted[0].id, 'DOM-1');
    assert.equal(extracted[0].title, 'Title A');
});
check('selector extraction attaches the explicit source URL', () => assert.equal(extracted[0].source_url, sourceUrl));

assert.equal(passed, 19, `Expected 19 case-validation checks, ran ${passed}`);
console.log(`SUMMARY: ${passed}/19 case-validation checks passed; 2/5 accepted; 3/5 rejected.`);
console.log('Node.js', process.version);
console.log(JSON.stringify(report, null, 2));
